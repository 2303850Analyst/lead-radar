/*
 * Representative excerpts only.
 * Sources:
 *   lib/search-planner/types.ts
 *   lib/search-planner/planner.ts
 *   lib/search-orchestrator.ts
 *   components/LeadRadarApp.tsx
 */

export type NormalizedSearchIntent = {
  description: string;
  primaryQuery: string;
  relatedQueries: string[];
  excludeQueries: string[];
  locale: SupportedLocale;
  countryCodes: [SupportedCountryCode];
};

export type SemanticIntentV2 = {
  schemaVersion: typeof SEMANTIC_INTENT_SCHEMA_VERSION;
  normalizedGoal: string;
  entityKind: SemanticEntityKind;
  physicalLocationRequirement: PhysicalPlaceRequirement;
  industries: string[];
  coreBusinessTypes: string[];
  adjacentBusinessTypes: string[];
  excludedBusinessTypes: string[];
  productsAndServices: string[];
  includeSignals: string[];
  excludeSignals: string[];
  retrievalTerms: {
    precision: string[];
    recall: string[];
    exclude: string[];
  };
  brandSearch: "include" | "exclude" | "only";
  confidence: ConfidenceBand;
  ambiguity: {
    isAmbiguous: boolean;
    reason: string | null;
    clarificationQuestion: string | null;
  };
};

// Actual type-level mismatch: the preview is named as Geoapify-only.
export type SearchPlanExecutionPreview = {
  provider: "geoapify";
  categoryLabels: string[];
  batches: number;
  retrievalArms: Array<{
    id: string;
    type: "precision" | "recall" | "adjacent" | "fallback" | "legacy";
    role: "primary" | "adjacent" | "fallback";
    priority: number;
    resultBudget: number;
    categoryLabels: string[];
    usesNameFallback: boolean;
    provenance: Array<unknown>;
  }>;
};

export type SearchPlan = {
  schemaVersion: typeof SEARCH_PLAN_SCHEMA_VERSION;
  taxonomyVersion: string;
  providerCatalogVersion: string;
  decisionPolicyVersion: string;
  promptVersion: string;
  requestCacheKey: string;
  planHash: string;
  parentPlanHash: string | null;
  status: PlanStatus;
  intent: NormalizedSearchIntent;
  semanticIntent: SemanticIntentV2;
  confidence: {
    intent: ConfidenceBand | "unknown";
    providerCoverage: ConfidenceBand | "unknown";
  };
  resolution: {
    method: "exact" | "semantic" | "kimi" | "user_confirmed" | "fallback";
    selectedConceptIds: string[];
    alternatives: SearchPlanAlternative[];
    confidenceBand: ConfidenceBand | "unknown";
    reasonCodes: ResolutionReasonCode[];
    clarificationQuestion: string | null;
  };
  executionPreview: SearchPlanExecutionPreview | null;
  ai: SearchPlanAiMetadata;
  confirmation: { token: string | null; expiresAt: string | null };
};

// lib/search-planner/planner.ts
export function plannerModeFromEnv(
  env: NodeJS.ProcessEnv = process.env,
): PlannerMode {
  const normalized = env.QUERY_INTELLIGENCE_MODE?.trim().toLowerCase();
  return normalized === "kimi" ? "kimi" : "deterministic";
}

export async function createSearchPlan(
  input: PlannerInput,
  options: CreateSearchPlanOptions = {},
): Promise<SearchPlan> {
  const intent = normalizePlannerInput(input);
  const requestCacheKey = await createRequestCacheKey(intent);
  const deterministic = resolveDeterministically(intent); // always first
  const mode = options.mode ?? "deterministic";

  // Known deterministic concept: directly executable.
  if (
    mode === "deterministic" &&
    deterministic.decision === "ready" &&
    deterministic.selectedConceptId
  ) {
    // finalize ready plan with ai.used=false
  }

  // Unknown deterministic concept: confirmation if alternatives exist,
  // otherwise an open-world fallback plan.
  if (mode === "deterministic") {
    const hasAlternatives = deterministicAlternatives.length > 0;
    return finalizePlan({
      ...common,
      status: hasAlternatives ? "needs_confirmation" : "ready",
      resolution: {
        method: "fallback",
        selectedConceptIds: [],
        alternatives: deterministicAlternatives,
        confidenceBand: "unknown",
        reasonCodes: hasAlternatives
          ? ["AMBIGUOUS_SCOPE"]
          : ["PROVIDER_COVERAGE_GAP"],
        clarificationQuestion: hasAlternatives
          ? clarificationQuestion(intent.locale)
          : null,
      },
      executionPreview: fallbackRecovery?.executionPreview ?? null,
      ai: AI_NOT_USED,
    }, signingOptions);
  }

  // Kimi output crosses a validation boundary before compilation.
  const result = await kimiClient.encode({ intent, signal: options.signal });
  const semanticIntent = validateKimiSemanticIntent(result.semanticIntent);
  const capabilityPlan = compileGeoapifySemanticIntent(semanticIntent, intent);
  // [...] physical/ambiguity/coverage policy follows
}

// lib/search-orchestrator.ts
async function search(initialPayload: SearchPayload): Promise<SearchResponse> {
  const hasConfirmation = Boolean(
    initialPayload.confirmationToken &&
      (initialPayload.confirmedAlternative ||
        initialPayload.confirmedConceptIds?.length),
  );
  const plan = hasConfirmation
    ? await dependencies.confirmPlan(initialPayload)
    : await dependencies.createPlan(initialPayload, signal);

  const providerId = dependencies.selectProvider();
  ensureExecutablePlan(plan, dependencies.isPlannerInfrastructureFailure, providerId);
  const payload = await dependencies.verifyGeography(initialPayload, signal);
  const provider = dependencies.providers[providerId];
  const prepared = await provider.prepare(plan);
  const response = await prepared.execute(payload, { onProgress, signal, runtime });
  return { ...response, plan };
}

// components/LeadRadarApp.tsx::runSearch
// The UI first previews a plan...
const planResult = await fetch("/api/search/plan", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(queryWithLocale),
  signal: controller.signal,
});

// ...then sends the original payload, not the returned SearchPlan.
setSearchPhase("searching");
await requestSearch(queryWithLocale, controller.signal);
