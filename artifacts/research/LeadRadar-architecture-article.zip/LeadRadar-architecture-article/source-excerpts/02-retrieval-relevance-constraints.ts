/*
 * Representative excerpts only.
 * Source: lib/providers/2gis.ts
 */

const MAX_ARMS = 3;
const MAX_RADIUS_METERS = 50_000;

export function compileTwoGisTextArms(
  payload: SearchPayload,
  semanticIntent?: SemanticIntentV2,
): TwoGisTextArm[] {
  const candidates: Array<Omit<TwoGisTextArm, "id" | "priority">> = [];
  // append(...) performs bounded string validation.
  append([payload.primaryQuery], semanticIntent ? "precision" : "fallback", "primary", "source.primaryQuery");
  if (semanticIntent) {
    append(semanticIntent.coreBusinessTypes, "precision", "primary", "coreBusinessTypes");
    append(semanticIntent.retrievalTerms.precision, "precision", "primary", "retrievalTerms.precision");
    append(semanticIntent.retrievalTerms.recall, "recall", "fallback", "retrievalTerms.recall");
    append(semanticIntent.productsAndServices, "recall", "fallback", "productsAndServices");
    append(semanticIntent.adjacentBusinessTypes, "adjacent", "adjacent", "adjacentBusinessTypes");
  } else {
    append(payload.relatedQueries, "fallback", "fallback", "source.relatedQueries");
  }

  const seen = new Set<string>();
  const unique = candidates.filter((candidate) => {
    const key = normalizeText(candidate.query);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  return unique.slice(0, MAX_ARMS).map((candidate, index) => ({
    ...candidate,
    id: `2gis-text-${index + 1}`,
    priority: index + 1,
  }));
}

function relevanceForItem(
  candidateId: string,
  item: TwoGisItem,
  payload: SearchPayload,
  semanticIntent: SemanticIntentV2 | undefined,
): LeadRelevance {
  const rubrics = itemRubrics(item);
  const name = itemName(item) ?? "";
  const categoryText = [
    ...rubrics.map((rubric) => rubric.name),
    stringValue(item.purpose_name, 160),
  ].filter(Boolean).join(" ");
  const description = stringValue(item.description, 800) ?? "";
  const sourceText = [name, categoryText, description].join(" ");
  const terms = semanticBusinessTerms(payload, semanticIntent);
  const excluded = terms.excluded.find((term) => termCoverage(sourceText, term) === 1);
  const exact = terms.strong.find((term) => termCoverage(sourceText, term) === 1);
  const partial = Math.max(0, ...terms.all.map((term) => termCoverage(sourceText, term)));

  if (excluded && !exact) {
    return {
      candidateId,
      status: "rejected",
      confidence: 0.9,
      evidence: [],
      reasonCodes: ["DGIS_EXCLUSION_EVIDENCE"],
      source: "deterministic",
    };
  }
  if (exact) {
    return {
      candidateId,
      status: "matched",
      confidence: 0.9,
      evidence: buildEvidenceFromActualItemFields(item, exact),
      reasonCodes: ["DGIS_EXACT_TEXT_EVIDENCE"],
      source: "deterministic",
    };
  }
  return {
    candidateId,
    status: "maybe",
    confidence: partial > 0 ? Math.min(0.65, 0.25 + partial * 0.4) : 0.25,
    evidence: [],
    reasonCodes: [partial > 0 ? "DGIS_WEAK_TEXT_EVIDENCE" : "DGIS_CANDIDATE_ONLY"],
    source: "deterministic",
  };
}

function evaluateFloorRequirement(
  requirement: string,
  item: TwoGisItem,
): RequirementMatchStatus {
  const requested = requestedFloorKinds(requirement);
  const observed = observedFloorKinds(item); // address_comment + floor_name
  if (!observed.size) return "unknown";
  const matches = [...observed].some((value) => requested.has(value));
  const conflicts = [...observed].some((value) => !requested.has(value));
  if (matches && conflicts) return "conflicting";
  return matches ? "confirmed_match" : "confirmed_mismatch";
}

function evaluateResidentialRequirement(
  item: TwoGisItem,
): RequirementMatchStatus {
  const buildingText = normalizeText(
    [item.building_name, item.full_name].filter(Boolean).join(" "),
  );
  if (!buildingText) return "unknown";
  const positive = RESIDENTIAL_PATTERN.test(buildingText);
  const negative = NON_RESIDENTIAL_PATTERN.test(buildingText);
  if (positive && negative) return "conflicting";
  if (positive) return "confirmed_match";
  if (negative) return "confirmed_mismatch";
  return "unknown";
}

function requirementsForItem(
  item: TwoGisItem,
  payload: SearchPayload,
  semanticIntent: SemanticIntentV2 | undefined,
): Lead["requirements"] {
  if (!semanticIntent) return [];
  // Business-type terms are removed; only additional requirements remain.
  return [...new Set(semanticIntent.includeSignals)]
    .filter((requirement) => !businessTerms.has(normalizeText(requirement)))
    .map((requirement) => {
      if (FLOOR_PATTERN.test(normalizeText(requirement))) {
        return { requirement, status: evaluateFloorRequirement(requirement, item) };
      }
      if (RESIDENTIAL_REQUIREMENT_PATTERN.test(normalizeText(requirement))) {
        return { requirement, status: evaluateResidentialRequirement(item) };
      }
      return {
        requirement,
        status: termCoverage(factText, requirement) === 1
          ? "confirmed_match"
          : "unknown",
      };
    });
}

/*
 * The placeholder names buildEvidenceFromActualItemFields and *_PATTERN above
 * replace verbose inline expressions from the source. They preserve the branch
 * structure while keeping this attachment short; README.md lists the exact
 * source fields and original key functions.
 */
