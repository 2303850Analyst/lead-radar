/*
 * Representative excerpts only.
 * Sources:
 *   lib/types.ts
 *   lib/search-planner/relevance.ts
 *   lib/providers/geoapify.ts
 *   scripts/canary-search-live.mjs
 */

export type SearchOutcome =
  | "success_with_results"
  | "success_empty"
  | "clarification_required"
  | "technical_failure";

export type RequirementMatchStatus =
  | "confirmed_match"
  | "confirmed_mismatch"
  | "unknown"
  | "conflicting";

export type LeadRelevance = {
  candidateId: string;
  status: "matched" | "maybe" | "rejected" | "not_checked";
  confidence: number | null;
  evidence: RelevanceEvidenceFact[];
  reasonCodes: string[];
  source: "deterministic" | "kimi" | "not_checked";
};

export type SearchResponse = {
  // Partial success is represented through coverage.degradedStages,
  // not through a separate outcome.
  outcome: Extract<SearchOutcome, "success_with_results" | "success_empty">;
  mode: SearchProviderId;
  provider: SearchProviderMetadata;
  query: SearchPayload;
  summary: SearchSummary;
  leads: Lead[];
  notice: string;
  generatedAt: string;
  plan?: SearchPlan;
};

// lib/search-planner/relevance.ts
export function classifyCandidateRelevance(
  evidence: CandidateEvidence,
  context: CandidateRelevanceContext,
): LeadRelevance {
  const exclusionFacts = findExclusionFacts(evidence, context);
  if (exclusionFacts.length) {
    return result(evidence.candidateId, "rejected", 0.98, exclusionFacts, ["EXCLUSION_MATCH"]);
  }

  const precisionCategoryFacts = findPrecisionCategoryFacts(evidence, context);
  const broadCategoryFacts = findBroadCategoryFacts(evidence, context);
  const termFacts = findPositiveTermFacts(evidence, context);
  const textTermFields = new Set(
    termFacts
      .filter((fact) => fact.field !== "providerCategoryIds")
      .map((fact) => fact.field),
  );

  if (precisionCategoryFacts.length) {
    return result(evidence.candidateId, "matched", 0.95,
      [...precisionCategoryFacts, ...broadCategoryFacts, ...termFacts],
      ["PROVIDER_CATEGORY_MATCH"]);
  }
  if ((broadCategoryFacts.length && textTermFields.size >= 1) || textTermFields.size >= 2) {
    return result(evidence.candidateId, "matched", 0.86,
      [...broadCategoryFacts, ...termFacts], ["MULTIPLE_EVIDENCE_MATCH"]);
  }
  if (broadCategoryFacts.length || termFacts.length) {
    return result(evidence.candidateId, "maybe", 0.64,
      [...broadCategoryFacts, ...termFacts], ["PARTIAL_EVIDENCE_MATCH"]);
  }
  if (evidence.providerCategoryIds.length) {
    return result(evidence.candidateId, "rejected", 0.8,
      categoryFacts(evidence.providerCategoryIds), ["PROVIDER_CATEGORY_CONFLICT"]);
  }
  return notCheckedRelevance(evidence.candidateId);
}

// lib/providers/geoapify.ts
const MAX_RETRIEVAL_ARMS = 4;
const MAX_RETRIEVAL_REQUESTS = 4;
const MAX_RETRIEVAL_CARDS = 200;

// At response construction time, rejected cards still count as results.
const response: SearchResponse = {
  outcome: leads.length ? "success_with_results" : "success_empty",
  // [...] query, provider coverage, summary, leads, notice, generatedAt
};

// scripts/canary-search-live.mjs::runLiteralBaseline
async function runLiteralBaseline(entry) {
  const url = new URL("https://api.geoapify.com/v1/geocode/search");
  url.searchParams.set("text", `${entry.literalBaselineQuery}, ${entry.city}`);
  url.searchParams.set("type", "amenity");
  url.searchParams.set(
    "filter",
    `circle:${entry.center[0]},${entry.center[1]},${Math.round(entry.radiusKm * 1_000)}`,
  );
  url.searchParams.set("bias", `proximity:${entry.center[0]},${entry.center[1]}`);
  url.searchParams.set("lang", entry.locale.slice(0, 2));
  url.searchParams.set("limit", String(literalBaselineLimit));
  // [...] live fetch, bounded JSON parsing, geography checks and deduplication
}

/*
 * Helper names such as findExclusionFacts/categoryFacts replace longer inline
 * expressions. The decision thresholds and branch ordering are unchanged.
 */
