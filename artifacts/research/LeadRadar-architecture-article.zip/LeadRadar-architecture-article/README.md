# LeadRadar: фактическая архитектура по коду

Материал подготовлен для статьи **“A Hybrid Semantic Architecture for Constraint-Aware Local Business Discovery”**. Это снимок фактической реализации: код проекта не изменялся, тесты и внешние API не запускались.

## 1. Путь запроса: `/api/search/plan` → `/api/search` → provider

`/api/search/plan` создаёт предварительный `SearchPlan`, однако интерфейс не передаёт этот объект в `/api/search`: он повторно отправляет исходный `SearchPayload`, и оркестратор повторно планирует запрос либо получает план из runtime-cache. После проверки плана оркестратор выбирает 2GIS/Geoapify, проверяет географию, вызывает provider Adapter через `prepare(plan)`, а затем выполняет подготовленный поиск.

Отдельного типа `SearchIntent` в коде нет. `NormalizedSearchIntent` содержит нормализованные исходные поля (`description`, `primaryQuery`, `relatedQueries`, `excludeQueries`, `locale`, `countryCodes`), `SemanticIntentV2` — смысл бизнеса, retrieval-термины, исключения, сигналы и неоднозначность, а `SearchPlan` — статус, resolution, версии, hash, AI-метаданные, execution preview и подтверждение. Есть расхождение с полностью provider-neutral описанием: `SearchPlanExecutionPreview.provider` типизирован только как `"geoapify"`, хотя фактически поиск может выполнять 2GIS.

Ключевые функции: `app/api/search/plan/route.ts::POST`, `components/LeadRadarApp.tsx::runSearch`, `lib/search-orchestrator.ts::createSearchOrchestrator().search`, `lib/search-planner/types.ts::{NormalizedSearchIntent, SemanticIntentV2, SearchPlan}`.

## 2. Deterministic и Kimi

Режим выбирается через `QUERY_INTELLIGENCE_MODE`: только значение `kimi` включает Kimi, любое другое значение означает deterministic; deterministic resolver при этом выполняется первым в обоих режимах. Неизвестный однозначный физический бизнес в deterministic-режиме получает fallback-план без provider category ID, неоднозначный запрос — `needs_confirmation`, а ошибка Kimi даёт исполнимый degraded-план только при найденной deterministic-концепции; при неизвестной концепции ошибка модели превращается в инфраструктурный отказ.

Повторный вызов Kimi между `/api/search/plan` и `/api/search` возможен, потому что поиск снова вызывает planner. Обычно его предотвращает десятиминутный runtime-cache, но после cache miss, истечения TTL, рестарта процесса или изменения версий/входа модель будет вызвана снова; подтверждение подписанной альтернативы Kimi не вызывает.

Ключевые функции: `lib/search-planner/planner.ts::{plannerModeFromEnv, createSearchPlan, createSearchPlanFromEnv, confirmSearchPlan}`, `lib/search-planner/resolver.ts::resolveDeterministically`.

## 3. Retrieval-формулировки, пределы, дедупликация и ранжирование

Для 2GIS portfolio строится в порядке: `primaryQuery`, core business types, precision terms, recall terms, products/services, adjacent types; после нормализации остаётся максимум три arm. Радиус 2GIS ограничен 50 км, production-настройка по умолчанию использует до 20 страниц по 50 результатов, абсолютный предел — 100 страниц.

Geoapify компилирует precision, recall, adjacent и fallback, ограничивая исполнение четырьмя arm, четырьмя upstream-запросами и 200 принятыми карточками; география фиксируется окружностью центра и радиуса. Дедупликация сначала использует provider ID, затем нормализованное имя и координаты; ранжирование учитывает relevance, независимые retrieval-arm, tier запроса, текстовое evidence и коммерческий score.

Ключевые функции: `lib/providers/2gis.ts::{compileTwoGisTextArms, identityKey, twoGisPaginationLimits}`, `lib/providers/geoapify.ts::{executeCompiledPlan, organizationIdentityKey, rankLeads}`, `lib/search-planner/catalogs/geoapify.ts::compileGeoapifySemanticIntent`.

## 4. `matched / maybe / rejected / not_checked` и confidence

В 2GIS полное покрытие сильного термина в названии, рубриках, назначении или описании даёт `matched` с confidence `0.9`; exclusion без сильного совпадения даёт `rejected 0.9`, остальные карточки становятся `maybe 0.25–0.65`. Штатная deterministic-классификация 2GIS практически не создаёт `not_checked`.

В Geoapify точная provider-категория даёт `matched 0.95`; широкая категория требует независимого текстового evidence (`matched 0.86`), единичный слабый признак даёт `maybe 0.64`, противоречащая provider-категория — `rejected 0.8`, отсутствие evidence — `not_checked`. Одна поисковая формулировка, по которой карточка была получена, не является основанием для `matched`; `relevance.confidence` также отличается от коммерческого `scores.confidence`.

Ключевые функции: `lib/providers/2gis.ts::{semanticBusinessTerms, relevanceForItem}`, `lib/search-planner/relevance.ts::{classifyCandidateRelevance, notCheckedRelevance}`, `lib/providers/geoapify.ts::candidateEvidence`.

## 5. Дополнительные требования

В 2GIS этаж проверяется по `address_comment` и `floor_name`, жилой дом — по `building_name` и `full_name`: совпавшие наблюдения дают `confirmed_match`, противоположные — `confirmed_mismatch`, одновременно положительные и отрицательные — `conflicting`, отсутствие фактов — `unknown`. Другие include-сигналы ищутся буквально в адресе, описании, здании и этаже и могут дать только `confirmed_match` либо `unknown`; Geoapify сейчас также в основном различает точное текстовое совпадение и `unknown`.

Общего итогового признака «полное совпадение» нет. Интерфейс не отображает `lead.requirements`, а показывает relevance и коммерческие оценки раздельно — это расходится с описанием продукта, если оно предполагает видимый пользователю итог проверки ограничений.

Ключевые функции: `lib/providers/2gis.ts::{evaluateFloorRequirement, evaluateResidentialRequirement, requirementsForItem}`, `lib/providers/geoapify.ts::normalizeLead`; тип результата — `lib/types.ts::RequirementMatchStatus`.

## 6. Пустая выдача, отклонения, глубина и технический сбой

`success_empty` означает отсутствие карточек; выдача, состоящая только из `rejected`, остаётся `success_with_results`, хотя стандартный UI-фильтр может скрыть все строки. Достижение page/depth limit не имеет отдельного outcome и у 2GIS не отражается явным флагом truncation.

Частичный отказ после получения данных возвращает результаты вместе с `provider.coverage.degradedStages`, а полный технический отказ становится `technical_failure`; неоднозначность становится `clarification_required`. В фактическом `SearchOutcome` нет `partial_success`: доступны outcome, summary, счётчики retrieval arms/upstream requests/cards/details, degraded stages и общий discovery notice.

Ключевые типы и функции: `lib/types.ts::{SearchOutcome, SearchResponse, SearchProviderMetadata}`, `app/api/search/route.ts::publicSearchError`, `components/LeadRadarApp.tsx::filteredLeads`.

## 7. Существующее сравнение Direct / Deterministic / Hybrid

Direct уже существует как literal baseline в live-canary; Deterministic — `createSearchPlan({ mode: "deterministic" })`; Hybrid — `createSearchPlan({ mode: "kimi" })`, где deterministic resolver работает первым, а Kimi уточняет семантику. Для одинаковых карточек доступны чистая `classifyCandidateRelevance`, фиксированный `CandidateEvidence` и внедряемый `fetch` у 2GIS; готовые примеры находятся в `tests/relevance.test.mjs`, `tests/2gis-provider.test.mjs`, `tests/search-planner.test.mjs` и offline eval-файлах.

Фактические пробелы: нет одного offline-harness, который запускает все три режима на одинаковых карточках и считает единую метрику; Direct baseline привязан к live Geoapify, а проверки требований 2GIS закрыты внутри provider-модуля и не представлены общей сравнительной функцией. Опциональная Kimi-классификация лидов существует как отдельная возможность, но Hybrid в основной архитектуре прежде всего означает гибридное планирование, а не обязательную post-retrieval AI-классификацию.

Ключевые функции и примеры: `scripts/canary-search-live.mjs::runLiteralBaseline`, `lib/search-planner/relevance.ts::classifyCandidateRelevance`, `tests/{relevance,2gis-provider,search-planner}.test.mjs`.

## Состав приложения

- `source-excerpts/01-planning-and-execution.ts` — типы intent/plan, выбор режима и повторное планирование.
- `source-excerpts/02-retrieval-relevance-constraints.ts` — bounded 2GIS retrieval, relevance и проверки ограничений.
- `source-excerpts/03-contract-and-comparison.ts` — SearchResponse/outcome, Geoapify relevance и Direct baseline.

Выдержки сокращены: опущенный код отмечен комментариями, исходные пути и ключевые функции сохранены.
