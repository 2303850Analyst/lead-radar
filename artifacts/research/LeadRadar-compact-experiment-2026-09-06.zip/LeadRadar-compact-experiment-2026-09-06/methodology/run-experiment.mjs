import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const repoRoot = process.env.LEADRADAR_ROOT;
if (!repoRoot) throw new Error("LEADRADAR_ROOT is required");

const moduleUrl = (relativePath) =>
  pathToFileURL(join(repoRoot, relativePath)).href;

const [
  { createKimiClientFromEnv, KIMI_MODEL_POLICY_VERSION, KIMI_TRANSPORT_SCHEMA_VERSION },
  { createSearchPlan, KIMI_PROMPT_VERSION, DECISION_POLICY_VERSION },
  { SEARCH_PLAN_SCHEMA_VERSION, SEMANTIC_INTENT_SCHEMA_VERSION },
  { TwoGisProvider, compileTwoGisTextArms, twoGisPaginationLimits },
  { GEOAPIFY_COMPILER_POLICY_VERSION, GEOAPIFY_PROVIDER_CATALOG_VERSION },
] = await Promise.all([
  import(moduleUrl("lib/search-planner/kimi-client.ts")),
  import(moduleUrl("lib/search-planner/planner.ts")),
  import(moduleUrl("lib/search-planner/types.ts")),
  import(moduleUrl("lib/providers/2gis.ts")),
  import(moduleUrl("lib/search-planner/catalogs/geoapify.ts")),
]);

const packageMetadata = JSON.parse(
  await readFile(join(repoRoot, "package.json"), "utf8"),
);
const gitCommit = process.env.LEADRADAR_GIT_COMMIT ?? "unknown";
const kimiClient = createKimiClientFromEnv(process.env);
if (!kimiClient) throw new Error("Kimi credentials are not configured");
if (!process.env.DGIS_API_KEY?.trim()) throw new Error("2GIS credentials are not configured");

const providerOptions = Object.freeze({
  demoMode: true,
  maxPages: 1,
  contactsEnabled: true,
  exportEnabled: true,
});
const pagination = twoGisPaginationLimits(providerOptions);

const cases = Object.freeze([
  {
    id: "ru-optician-moscow",
    description: "Найти салоны оптики с подбором очков",
    query: "салон оптики с подбором очков",
    city: "Москва",
    center: [37.6173, 55.7558],
    radiusKm: 10,
    locale: "ru-RU",
    countryCode: "RU",
  },
  {
    id: "ru-music-school-yekaterinburg",
    description: "Найти музыкальные школы и студии обучения музыке",
    query: "музыкальная школа",
    city: "Екатеринбург",
    center: [60.5975, 56.8389],
    radiusKm: 10,
    locale: "ru-RU",
    countryCode: "RU",
  },
  {
    id: "ru-dentistry-novosibirsk",
    description: "Найти стоматологические клиники",
    query: "стоматология",
    city: "Новосибирск",
    center: [82.9204, 55.0302],
    radiusKm: 10,
    locale: "ru-RU",
    countryCode: "RU",
  },
  {
    id: "by-veterinary-minsk",
    description: "Знайсці ветэрынарныя арганізацыі і паслугі для жывёл",
    query: "ветэрынарныя паслугі для жывёл",
    city: "Минск",
    center: [27.5615, 53.9045],
    radiusKm: 10,
    locale: "be-BY",
    countryCode: "BY",
  },
  {
    id: "kz-kindergarten-almaty",
    description: "Алматыдағы балабақшаларды табу",
    query: "балабақша kindergarten",
    city: "Алматы",
    center: [76.886, 43.238],
    radiusKm: 10,
    locale: "kk-KZ",
    countryCode: "KZ",
  },
  {
    id: "ru-bicycle-repair-moscow",
    description: "Найти мастерские по ремонту велосипедов",
    query: "мастерская по ремонту велосипедов",
    city: "Москва",
    center: [37.6173, 55.7558],
    radiusKm: 10,
    locale: "ru-RU",
    countryCode: "RU",
  },
]);

const inputFor = (entry) => ({
  description: entry.description,
  primaryQuery: entry.query,
  relatedQueries: [],
  excludeQueries: [],
  locale: entry.locale,
  countryCodes: [entry.countryCode],
});

const payloadFor = (entry) => ({
  ...inputFor(entry),
  location: entry.city,
  locationMode: "radius",
  center: entry.center,
  radiusKm: entry.radiusKm,
  services: [],
});

function sanitizePlan(plan) {
  return {
    status: plan.status,
    method: plan.resolution.method,
    reasonCodes: [...plan.resolution.reasonCodes],
    selectedConceptCount: plan.resolution.selectedConceptIds.length,
    alternativeCount: plan.resolution.alternatives.length,
    executionArmCount: plan.executionPreview?.retrievalArms.length ?? 0,
    ai: {
      used: plan.ai.used,
      validation: plan.ai.validation,
      modelId: plan.ai.modelId,
      latencyMs: plan.ai.latencyMs,
      inputTokens: plan.ai.inputTokens,
      outputTokens: plan.ai.outputTokens,
      cacheHit: plan.ai.cacheHit,
    },
  };
}

function sanitizeSearch(response, durationMs) {
  const top10 = response.leads.slice(0, 10);
  return {
    executed: true,
    outcome: response.outcome,
    durationMs,
    leadCount: response.leads.length,
    uniqueLocations: response.summary.uniqueLocations,
    foundByPrimary: response.summary.foundByPrimary,
    foundOnlyExpanded: response.summary.foundOnlyExpanded,
    relevance: response.summary.relevance,
    top10: {
      matched: top10.filter((lead) => lead.relevance?.status === "matched").length,
      maybe: top10.filter((lead) => lead.relevance?.status === "maybe").length,
      rejected: top10.filter((lead) => lead.relevance?.status === "rejected").length,
      notChecked: top10.filter((lead) => lead.relevance?.status === "not_checked").length,
    },
    coverage: {
      retrievalArms: response.provider.coverage?.retrievalArms ?? null,
      completedRetrievalArms:
        response.provider.coverage?.completedRetrievalArms ?? null,
      upstreamRequests: response.provider.coverage?.upstreamRequests ?? null,
      cardsAccepted: response.provider.coverage?.cardsAccepted ?? null,
      degradedStages: response.provider.coverage?.degradedStages ?? [],
    },
  };
}

async function executeProvider(payload, semanticIntent) {
  const provider = new TwoGisProvider(process.env.DGIS_API_KEY, providerOptions);
  const startedAt = Date.now();
  const response = await provider.search(payload, { semanticIntent });
  return sanitizeSearch(response, Date.now() - startedAt);
}

async function safeRun(run) {
  try {
    return await run();
  } catch (error) {
    return {
      executed: false,
      errorCode:
        typeof error === "object" && error && "code" in error
          ? String(error.code)
          : "UNCLASSIFIED_EXPERIMENT_ERROR",
    };
  }
}

const startedAt = new Date();
const results = [];
const kimiStartIntervalMs = Number(
  process.env.KIMI_MIN_START_INTERVAL_MS ?? 20_000,
);
let lastKimiStartAt = 0;

async function waitForKimiSlot() {
  const remaining = lastKimiStartAt + kimiStartIntervalMs - Date.now();
  if (remaining > 0) {
    await new Promise((resolve) => setTimeout(resolve, remaining));
  }
  lastKimiStartAt = Date.now();
}

for (const entry of cases) {
  const input = inputFor(entry);
  const payload = payloadFor(entry);

  const directArms = compileTwoGisTextArms(payload);
  const direct = await safeRun(() => executeProvider(payload, undefined));

  const deterministicPlan = await createSearchPlan(input, { mode: "deterministic" });
  const deterministic = ["ready", "degraded"].includes(deterministicPlan.status)
    ? await safeRun(() => executeProvider(payload, deterministicPlan.semanticIntent))
    : { executed: false, errorCode: `PLAN_${deterministicPlan.status.toUpperCase()}` };

  await waitForKimiSlot();
  const hybridPlan = await createSearchPlan(input, {
    mode: "kimi",
    kimiClient,
  });
  const hybrid = ["ready", "degraded"].includes(hybridPlan.status)
    ? await safeRun(() => executeProvider(payload, hybridPlan.semanticIntent))
    : { executed: false, errorCode: `PLAN_${hybridPlan.status.toUpperCase()}` };

  results.push({
    id: entry.id,
    countryCode: entry.countryCode,
    locale: entry.locale,
    city: entry.city,
    query: entry.query,
    radiusKm: entry.radiusKm,
    direct: {
      plan: null,
      retrievalArmCount: directArms.length,
      search: direct,
    },
    deterministic: {
      plan: sanitizePlan(deterministicPlan),
      search: deterministic,
    },
    hybrid: {
      plan: sanitizePlan(hybridPlan),
      search: hybrid,
    },
  });
}

function median(values) {
  if (!values.length) return null;
  const sorted = [...values].sort((left, right) => left - right);
  return sorted[Math.floor(sorted.length / 2)];
}

function summarizeMode(mode) {
  const searches = results.map((entry) => entry[mode].search);
  const executed = searches.filter((entry) => entry.executed);
  return {
    cases: searches.length,
    executedCases: executed.length,
    successWithResults: executed.filter(
      (entry) => entry.outcome === "success_with_results",
    ).length,
    successEmpty: executed.filter((entry) => entry.outcome === "success_empty").length,
    failedOrNotExecutable: searches.length - executed.length,
    totalLeads: executed.reduce((sum, entry) => sum + entry.leadCount, 0),
    totalMatched: executed.reduce(
      (sum, entry) => sum + (entry.relevance?.matched ?? 0),
      0,
    ),
    totalMaybe: executed.reduce(
      (sum, entry) => sum + (entry.relevance?.maybe ?? 0),
      0,
    ),
    top10Matched: executed.reduce((sum, entry) => sum + entry.top10.matched, 0),
    upstreamRequests: executed.reduce(
      (sum, entry) => sum + (entry.coverage.upstreamRequests ?? 0),
      0,
    ),
    medianProviderLatencyMs: median(executed.map((entry) => entry.durationMs)),
  };
}

const hybridAi = results.map((entry) => entry.hybrid.plan.ai);
const inputTokens = hybridAi.reduce((sum, entry) => sum + (entry.inputTokens ?? 0), 0);
const outputTokens = hybridAi.reduce((sum, entry) => sum + (entry.outputTokens ?? 0), 0);

const report = {
  experiment: "LeadRadar compact Direct / Deterministic / Hybrid live experiment",
  scope: {
    cases: cases.length,
    countries: [...new Set(cases.map((entry) => entry.countryCode))],
    cities: [...new Set(cases.map((entry) => entry.city))],
    provider: "2gis",
    liveExternalCalls: true,
    rawProviderResponsesStored: false,
    leadRecordsStored: false,
    note:
      "Modes use the same provider, city, radius and execution window, but may retrieve different candidate pools because their query arms differ.",
  },
  versions: {
    appVersion: packageMetadata.version,
    gitCommit,
    kimiModelId: kimiClient.modelId,
    kimiModelPolicyVersion: KIMI_MODEL_POLICY_VERSION,
    kimiTransportSchemaVersion: KIMI_TRANSPORT_SCHEMA_VERSION,
    kimiPromptVersion: KIMI_PROMPT_VERSION,
    semanticIntentSchemaVersion: SEMANTIC_INTENT_SCHEMA_VERSION,
    searchPlanSchemaVersion: SEARCH_PLAN_SCHEMA_VERSION,
    decisionPolicyVersion: DECISION_POLICY_VERSION,
    compilerPolicyVersion: GEOAPIFY_COMPILER_POLICY_VERSION,
    providerCatalogVersion: GEOAPIFY_PROVIDER_CATALOG_VERSION,
  },
  settings: {
    kimi: {
      baseUrlHost: new URL(kimiClient.baseUrl).host,
      model: kimiClient.modelId,
      mode: "k2.6-thinking-disabled",
      reasoningEffort: null,
      requestControl: { thinking: { type: "disabled" } },
      responseFormat: "json_object",
      maxCompletionTokens: 1200,
      stream: true,
      includeUsage: true,
      timeoutMs: Number(process.env.KIMI_REQUEST_TIMEOUT_MS ?? 30000),
      minStartIntervalMs: Number(process.env.KIMI_MIN_START_INTERVAL_MS ?? 20000),
      admissionTimeoutMs: Number(process.env.KIMI_ADMISSION_TIMEOUT_MS ?? 20000),
    },
    twoGis: {
      endpoint: "catalog.api.2gis.com/3.0/items",
      demoMode: providerOptions.demoMode,
      pageSize: pagination.pageSize,
      maxPages: pagination.maxPages,
      maxResultsPerArm: pagination.maxResultsPerArm,
      maxArms: 3,
      contactsEnabled: providerOptions.contactsEnabled,
      exportEnabled: providerOptions.exportEnabled,
      radiusKm: 10,
    },
  },
  startedAt: startedAt.toISOString(),
  finishedAt: new Date().toISOString(),
  summary: {
    direct: summarizeMode("direct"),
    deterministic: summarizeMode("deterministic"),
    hybrid: summarizeMode("hybrid"),
    hybridKimi: {
      calls: hybridAi.length,
      usedAndValidated: hybridAi.filter(
        (entry) => entry.used && entry.validation === "passed",
      ).length,
      cacheHits: hybridAi.filter((entry) => entry.cacheHit).length,
      inputTokens,
      outputTokens,
      estimatedCostUsd:
        (inputTokens / 1_000_000) * 0.95 + (outputTokens / 1_000_000) * 4,
      medianLatencyMs: median(
        hybridAi.map((entry) => entry.latencyMs).filter(Number.isFinite),
      ),
    },
  },
  cases: results,
};

process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
