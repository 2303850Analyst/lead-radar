# Experiment methodology

## Main comparison

`run-experiment.mjs` imports the production planner, Kimi client and 2GIS provider modules from the checked LeadRadar repository. It executes six fixed cases in Direct, Deterministic and Hybrid modes and emits only aggregate/sanitized JSON.

The final run used a 20-second minimum interval between Kimi starts. A preliminary harness run without that explicit interval was discarded because direct use of the low-level client bypassed the production scheduler and triggered its circuit breaker after rapid calls; no LeadRadar source file was changed.

Direct, Deterministic and Hybrid share the same provider, center, radius and time window, but they do not operate over a frozen common card set: semantic modes may issue additional query arms and consequently obtain a different candidate pool. The comparison therefore measures retrieval behavior, internal relevance labeling, provider work and latency—not manually adjudicated precision or recall.

## Reproduction requirements

- checkout commit `b1fd365259764407734e14e8f6a90e9b112fdaf5`;
- Node dependencies installed;
- `LEADRADAR_ROOT` pointing to the checkout;
- Kimi key available only as `MOONSHOT_API_KEY` or `KIMI_API_KEY`;
- 2GIS key available only as `DGIS_API_KEY`;
- `KIMI_PLANNER_MODEL=kimi-k2.6`;
- `KIMI_PLANNER_REASONING_EFFORT` unset;
- `KIMI_REQUEST_TIMEOUT_MS=30000`;
- `KIMI_MIN_START_INTERVAL_MS=20000`;
- `KIMI_ADMISSION_TIMEOUT_MS=20000`.

Run from the repository with the project’s TypeScript loader:

```text
node --env-file-if-exists=.env.local --conditions=react-server --import tsx <path-to>/run-experiment.mjs
```

Do not put credentials into this directory or its ZIP. The supplied harness prints results to standard output and does not persist raw provider responses or lead records.

## Other evidence

The Kimi live canary is the repository’s existing `tests/kimi-live-eval.mjs` with all five built-in cases. The offline summaries come from `eval:legacy`, `eval:open-world` and `eval:relevance`; the regression summary comes from the three selected test files listed in `results/regression-tests.txt`.

