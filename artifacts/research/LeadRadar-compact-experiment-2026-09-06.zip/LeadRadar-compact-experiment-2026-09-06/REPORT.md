# LeadRadar compact experiment report

**Purpose:** provide a compact, reproducible factual snapshot for the article *“A Hybrid Semantic Architecture for Constraint-Aware Local Business Discovery”*.

**Checked:** 6 September 2026, 01:13–01:21 MSK (5 September 2026, 22:13–22:21 UTC).

**Code snapshot:** application `0.4.0-alpha.1`, Git commit `b1fd365259764407734e14e8f6a90e9b112fdaf5`, branch `feat/kimi-query-intelligence`.

## 1. What was tested

The main live experiment used six unambiguous, neutral physical-business queries in five cities and three countries:

1. optical store with glasses fitting — Moscow, RU;
2. music school — Yekaterinburg, RU;
3. dental clinic — Novosibirsk, RU;
4. veterinary services in Belarusian — Minsk, BY;
5. kindergarten in mixed Kazakh/English — Almaty, KZ;
6. bicycle repair workshop — Moscow, RU.

Every case used the same city center, a 10 km radius, the same short execution window and the live 2GIS provider. Three modes were compared:

- **Direct:** the literal user query was sent to the production 2GIS Adapter as one retrieval arm, without semantic planning.
- **Deterministic:** the production deterministic planner created `SemanticIntentV2`, then the same 2GIS Adapter executed the resulting text portfolio when the plan was executable.
- **Hybrid:** deterministic resolution ran first, Kimi encoded the semantic intent, server validation/compilation followed, then the same 2GIS Adapter executed the bounded portfolio when the plan was executable.

No raw provider responses, business cards, names, addresses, contacts or API keys were stored. Only aggregate counts, plan states, latency, token usage and provider-coverage counters were retained.

## 2. Main live result

| Metric | Direct | Deterministic | Hybrid |
|---|---:|---:|---:|
| Cases attempted | 6 | 6 | 6 |
| Executable cases | 6 | 4 | 5 |
| Cases returning results | 6 | 4 | 5 |
| Candidates returned | 55 | 35 | 89 |
| Internally classified `matched` | 24 | 17 | 48 |
| Internally classified `maybe` | 31 | 18 | 41 |
| `matched` among displayed top-10 groups | 24 | 17 | 42 |
| 2GIS upstream requests | 6 | 4 | 15 |
| Median provider latency | 68 ms | 59 ms | 217 ms |

Hybrid returned **89 candidates versus 55 for Direct** and **48 internal `matched` labels versus 24**, despite executing only five of the six cases. This broader retrieval required **2.5× more 2GIS requests** (15 versus 6), because Hybrid executed up to three semantic retrieval arms instead of one literal arm.

The most visible gains were:

- optical store: Direct `10 candidates / 0 matched`; Hybrid `18 / 12`;
- music school: Direct `10 / 7`; Deterministic stopped for confirmation; Hybrid `18 / 10`;
- mixed-language kindergarten: Direct `5 / 5`; Hybrid `16 / 14`;
- bicycle repair: Direct `10 / 2`; Hybrid `23 / 4`.

For dentistry, Direct and Deterministic were already strong (`10 / 10`), while Hybrid broadened the pool to 14 but produced 8 `matched`. Hybrid therefore did not uniformly improve every query.

## 3. Kimi reliability and cost

In the six-case comparison, Kimi was called six times and produced a schema-valid semantic intent five times (`83.3%`). The Minsk veterinary case returned `KIMI_INVALID_RESPONSE`; because deterministic resolution had also requested confirmation, Hybrid did not call 2GIS for that case.

Kimi totals for the main experiment:

- input tokens: `6,954`;
- output tokens: `1,644`;
- median reported model latency: `6,697 ms`;
- estimated cost using the configured comparison rates (`$0.95/M input`, `$4/M output`): **$0.01318** total, or approximately **$0.00220 per attempted Hybrid case**.

The repository’s independent five-case live Kimi canary also returned `FAIL`: four of five outputs passed schema validation, Kimi was used in all five cases, and the model-availability check passed. Two control decisions were correct (ambiguous warehouse → confirmation; non-physical cloud CRM → unsupported), while pharmacy and car wash produced executable open-world plans without the legacy canonical concept IDs expected by that older gate, and the barbershop paraphrase failed semantic validation.

The canary’s `exactConceptAccuracy=0.4` must therefore not be interpreted as end-to-end search precision. It combines two true control successes, two executable open-world plans rejected by a legacy exact-ID expectation, and one actual invalid model response.

## 4. Exact Kimi and application configuration

### Kimi

- API host: `api.moonshot.ai`;
- model: `kimi-k2.6`;
- model mode: `k2.6-thinking-disabled`;
- reasoning effort: not applicable (`null`);
- request control: `thinking: { type: "disabled" }`;
- response format: `json_object`;
- `max_completion_tokens`: `1200`;
- streaming: enabled;
- streaming usage reporting: enabled;
- request timeout: `30000 ms`;
- experiment start interval: `20000 ms`;
- admission timeout recorded by the application profile: `20000 ms`;
- model policy: `kimi-model-policy/2026-08-20.6`;
- transport schema: `mfjs-semantic-intent/2026-08-20.5`;
- prompt identity: `semantic-intent-v2/2026-08-20.9+kimi-model-policy/2026-08-20.6`.

### LeadRadar and provider compiler

- app version: `0.4.0-alpha.1`;
- SemanticIntent schema: `2.2`;
- SearchPlan schema: `2.2`;
- decision policy: `2026-08-22.1`;
- compiler policy: `semantic-retrieval-v2/2026-08-22.2`;
- provider catalog version: `2026-08-17.1`;
- active provider: live 2GIS Places endpoint `catalog.api.2gis.com/3.0/items`.

### Bounded 2GIS settings used in the comparison

- demo pagination mode: enabled;
- page size: `10`;
- maximum pages per arm: `1` (experiment bound; the local application normally permits a deeper default);
- maximum cards per arm: `10`;
- maximum semantic arms: `3`;
- radius: `10 km`;
- contacts option: enabled, but contacts were neither retained nor reported;
- export capability flag: enabled, but no export was performed.

## 5. Offline and regression controls

Three existing aggregate-only offline evaluations passed:

- Query Intelligence: 222 planner cases, 500 open-world planner cases and 600 classifier cases; all reported headline metrics were `1.0`, with zero hard-gate violations.
- Open-world CIS: 500 intents across 150 business families and RU/BY/KZ; `falseUnsupported=0`, `semanticOutcomeAccuracy=1.0`, `exactExpectedCategoryCoverage=0.8222`, zero hard-gate violations.
- Deterministic relevance: 600 candidates evenly divided among `matched/maybe/rejected/not_checked`; precision, recall, evidence validity and outcome accuracy were `1.0`, zero hard-gate violations.

The selected regression suite covering planner, relevance and 2GIS provider behavior passed **81/81 tests** in approximately 20.1 seconds. These offline results validate deterministic fixtures and invariants; they do not substitute for live provider ground truth.

## 6. Interpretation and limitations

The result supports the narrow claim that semantic planning can increase candidate acquisition and the number of candidates supported by the application’s own evidence rules. It does **not** establish real-world precision, recall, business existence or constraint satisfaction because no human reviewed the returned organizations and each mode can retrieve a different candidate pool.

The six cases are a compact engineering experiment, not a statistically powered benchmark. Provider latency excludes Kimi planning time; Hybrid’s user-visible latency is dominated by the model (median about 6.7 seconds), while the provider portion remained below one second in this run.

The live failure rate is material: one of six Hybrid cases was blocked by invalid Kimi output. The current implementation therefore demonstrates higher breadth when semantic validation succeeds, but not guaranteed availability across all neutral physical-business inputs.

## 7. Article-ready statement

> In a compact live experiment over six neutral local-business intents spanning five CIS cities and three countries, the hybrid planner retrieved 89 candidates with 48 application-classified matches, compared with 55 candidates and 24 matches for literal direct search. This gain required 15 provider requests instead of six, and one of six hybrid cases did not reach the provider because the Kimi response failed schema validation. Since relevance labels were produced by the system rather than human annotators, these measurements characterize retrieval breadth and internal evidence support, not ground-truth precision or recall.

## Included evidence

- `results/full-stack-aggregate.json` — sanitized main comparison and per-case counts.
- `results/kimi-live-canary.json` — repository-produced aggregate-only live Kimi canary.
- `results/offline-evaluations.json` — three existing offline evaluation summaries.
- `results/regression-tests.txt` — selected regression suite result.
- `methodology/run-experiment.mjs` — exact temporary harness used for the main comparison.
- `methodology/README.md` — method and reproducibility notes.

