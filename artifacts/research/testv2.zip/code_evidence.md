# Проверенные точки кода

Полные `.ts/.tsx` файлы в архив не копировались: для воспроизводимости достаточно версии Git и следующих функций.

- `package.json` — каноническая версия приложения `0.4.0-alpha.1`.
- `components/LeadRadarApp.tsx`, `runSearch` — UI сначала вызывает `/api/search/plan`, затем `/api/search?stream=1`; клиентский таймаут 62 секунды.
- `lib/search-planner/kimi-client.ts`, `resolveKimiModelPolicy` — для `kimi-k2.6` reasoning effort запрещён, отправляется `thinking: { type: "disabled" }`.
- `lib/search-planner/kimi-client.ts`, `createKimiClient` — endpoint `/chat/completions`, `response_format: json_object`, streaming, usage in stream options и `max_completion_tokens: 1200`.
- `lib/search-planner/kimi-client.ts`, constants — default base URL, 30-секундный timeout, model/transport policy versions.
- `lib/search-planner/planner.ts` — prompt version, decision policy version, runtime cache TTL 10 минут и максимум 200 записей.
- `app/api/search/route.ts`, health response — фактические provider/configuration/runtime counters, использованные в `runtime_configuration.json`.
- `lib/providers/2gis.ts`, `twoGisPaginationLimits` — одна страница по 10 результатов на query arm при экспериментальном override `DGIS_MAX_PAGES=1`.

Git commit полностью фиксирует содержимое этих файлов: `b1fd365259764407734e14e8f6a90e9b112fdaf5`.
